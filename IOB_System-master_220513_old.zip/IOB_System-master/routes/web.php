<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ImageUploadController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

Route::get('locale', function () {
    return \App::getLocale();
});

// Put the selected locale to the session
Route::get('locale/{locale}', function ($locale) {
    \Session::put('locale', $locale);
    return redirect()->back();
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('image-upload', [ ImageUploadController::class, 'imageUpload' ])->name('image.upload');
Route::post('image-upload', [ ImageUploadController::class, 'imageUploadPost' ])->name('image.upload.post');


Route::resource('itemcategory', 'itemcategoryController');
Route::resource('items', 'itemsController');
Route::resource('user', 'userController');
Route::resource('shop', 'shopController');
Route::resource('cart', 'cartController');


//Migration version 1
Route::resource('accounts ', 'Controllers_v1_AccountController');
Route::resource('permissions ', 'Controllers_v1_PermissionController');
Route::resource('roles ', 'Controllers_v1_RoleController');
Route::resource('pictures ', 'Controllers_v1_PictureController');
Route::resource('discounts ', 'Controllers_v1_DiscountController');
Route::resource('subscriptions ', 'Controllers_v1_SubscriptionController');
Route::resource('itemsv1 ', 'Controllers_v1_Itemv1Controller');
Route::resource('itemprices ', 'Controllers_v1_ItempriceController');
Route::resource('itemdetailpremiumplans ', 'Controllers_v1_ItemdetailpremiumplanController');
Route::resource('itemdetailbooks ', 'Controllers_v1_ItemdetailbookController');
Route::resource('ebooks ', 'Controllers_v1_EbookController');
Route::resource('iteminventories ', 'Controllers_v1_IteminventoryController');
Route::resource('categories ', 'Controllers_v1_CategoryController');
Route::resource('subcategories ', 'Controllers_v1_SubcategoryController');
Route::resource('itemcategories ', 'Controllers_v1_ItemcategoryController');
Route::resource('adjustments ', 'Controllers_v1_AdjustmentController');
Route::resource('orderstatuses ', 'Controllers_v1_OrderstatusController');
Route::resource('paymentstatuses ', 'Controllers_v1_PaymentstatusController');
Route::resource('shipmentstatuses ', 'Controllers_v1_ShipmentstatusController');
Route::resource('orders ', 'Controllers_v1_OrderController');
Route::resource('orderitemsv1 ', 'Controllers_v1_Orderitemv1Controller');
Route::resource('orderitemunitsv1 ', 'Controllers_v1_Orderitemunitv1Controller');
Route::resource('ordershipmentdetails ', 'Controllers_v1_OrdershipmentdetailController');
Route::resource('purchaseitems ', 'Controllers_v1_PurchaseitemController');
Route::resource('orderorderstatuses ', 'Controllers_v1_OrderorderstatusController');
Route::resource('orderpaymentstatuses ', 'Controllers_v1_OrderpaymentstatusController');
Route::resource('contentpages ', 'Controllers_v1_ContentpageController');
Route::resource('contentposts ', 'Controllers_v1_ContentpostController');
Route::resource('tags ', 'Controllers_v1_TagController');
Route::resource('tagcontentpages ', 'Controllers_v1_TagcontentpageController');
Route::resource('categorycontentpages ', 'Controllers_v1_CategorycontentpageController');
Route::resource('followercontentpages ', 'Controllers_v1_FollowercontentpageController');
Route::resource('eventposts ', 'Controllers_v1_EventpostController');
Route::resource('eventparticipations ', 'Controllers_v1_EventparticipationController');


