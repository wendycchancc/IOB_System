<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrderitemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('orderitemsv1', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('orderId');
			$table->unsignedBigInteger('accIdSell');
			$table->unsignedBigInteger('accIdBuy');
			$table->unsignedBigInteger('itemId');
			$table->unsignedBigInteger('itemPriceId');
			$table->unsignedBigInteger('adjustmentId')->nullable();
			$table->unsignedSmallInteger('quantity')->default(1);
			$table->decimal('priceTotal', 10, 2)->nullable();
			$table->char('currency', 4);
			
			
			//Create the created_at and updated_at columns.
			$table->timestamps($precision = 0);
			//Create the createdBy and updatedBy columns.
			$table->unsignedBigInteger('createdBy')->nullable();
			$table->unsignedBigInteger('updatedBy')->nullable();
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('createdBy')->references('id')->on('accounts');
			$table->foreign('updatedBy')->references('id')->on('accounts');
			$table->foreign('orderId')->references('id')->on('orders');
			$table->foreign('accIdSell')->references('accId')->on('itemsv1');
			$table->foreign('accIdBuy')->references('accIdBuy')->on('orders');
			$table->foreign('itemId')->references('id')->on('itemsv1');
			$table->foreign('itemPriceId')->references('id')->on('itemprices');
			$table->foreign('adjustmentId')->references('id')->on('adjustments');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orderitemsv1');
    }
}
