<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddForeignKeyaccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        
        Schema::table('accounts', function($table) {
            // Create foreign key index
            $table->foreign('updatedBy')->references('id')->on('accounts');
            $table->foreign('roleId')->references('id')->on('roles');
            $table->foreign('profilePicId')->references('id')->on('pictures');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
	Schema::table('accounts', function (Blueprint $table) {
    		$table->dropForeign(['updatedBy']);
    		$table->dropForeign(['roleId']);
    		$table->dropForeign(['profilePicId']);
});

    }
}
