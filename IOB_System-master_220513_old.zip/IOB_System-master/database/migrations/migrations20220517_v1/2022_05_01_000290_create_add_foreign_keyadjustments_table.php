<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAddForeignKeyadjustmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        
        Schema::table('adjustments', function($table) {
			// Create foreign key index
			$table->foreign('orderId')->references('id')->on('orders');
			$table->foreign('orderitemId')->references('id')->on('orderitemsv1');
			$table->foreign('orderitemsunitId')->references('id')->on('orderitemunitsv1');
			$table->foreign('discountId')->references('id')->on('discounts');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
	Schema::table('adjustments', function (Blueprint $table) {
    		$table->dropForeign(['orderId']);
    		$table->dropForeign(['orderitemId']);
    		$table->dropForeign(['orderitemsunitId']);
    		$table->dropForeign(['discountId']);
});

    }

}
