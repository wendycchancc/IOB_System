<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('orders', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('accIdBuy');
			$table->decimal('priceSum', 10, 2)->default(0);
			$table->char('currency', 4);
			$table->decimal('priceTotal', 10, 2)->default(0);
			$table->unsignedSmallInteger('orderStatusId')->nullable();
			$table->unsignedSmallInteger('paymentStatusId')->nullable();
			$table->text('desc')->nullable();
			
			
			//Create the created_at and updated_at columns.
			$table->timestamps($precision = 0);
			//Create the createdBy and updatedBy columns.
			$table->unsignedBigInteger('createdBy');
			$table->unsignedBigInteger('updatedBy')->nullable();
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('createdBy')->references('id')->on('accounts');
			$table->foreign('updatedBy')->references('id')->on('accounts');
			$table->foreign('accIdBuy')->references('id')->on('accounts');
			$table->foreign('orderStatusId')->references('id')->on('orderstatuses');
			$table->foreign('paymentStatusId')->references('id')->on('paymentstatuses');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
