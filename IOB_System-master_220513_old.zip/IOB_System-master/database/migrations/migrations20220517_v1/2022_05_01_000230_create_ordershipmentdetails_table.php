<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdershipmentdetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('ordershipmentdetails', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedbigInteger('orderId');
			$table->string('name', 255);
			$table->string('email', 255)->nullable();
			$table->integer('phone');
			$table->string('address', 255);
			$table->string('postcode', 255)->nullable();
			$table->text('desc')->nullable();
			
			
			//Create the created_at and updated_at columns.
			$table->timestamps($precision = 0);
			//Create the createdBy and updatedBy columns.
			$table->unsignedBigInteger('createdBy')->nullable();
			$table->unsignedBigInteger('updatedBy')->nullable();
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('createdBy')->references('id')->on('accounts');
			$table->foreign('updatedBy')->references('id')->on('accounts');
			$table->foreign('orderId')->references('id')->on('orders');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ordershipmentdetails');
    }
}
