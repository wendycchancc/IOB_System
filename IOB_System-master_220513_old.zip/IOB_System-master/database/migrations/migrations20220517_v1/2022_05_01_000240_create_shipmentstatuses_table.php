<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateShipmentstatusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('shipmentstatuses', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('orderId')->nullable();
			$table->unsignedBigInteger('orderitemunitId')->nullable();
			$table->string('title', 255);
			$table->text('shipmentLabel')->nullable();
			$table->text('desc')->nullable();
			
			
			//Create the created_at column.
			$table->timestamp('created_at', $precision = 0);
			//Create the createdBy columns.
			$table->unsignedBigInteger('createdBy');
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('createdBy')->references('id')->on('accounts');
			$table->foreign('orderId')->references('id')->on('orders');
			$table->foreign('orderitemunitId')->references('id')->on('orderitemunitsv1');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('shipmentstatuses');
    }
}
