<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdjustmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('adjustments', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('orderId')->nullable();
			$table->unsignedBigInteger('orderitemId')->nullable();
			$table->unsignedBigInteger('orderitemsunitId')->nullable();
			$table->string('type', 255);
			$table->unsignedBigInteger('discountId')->nullable();
			$table->string('discountCode', 255)->nullable();
			$table->decimal('amountAdjust', 10, 5);
			$table->char('currency', 4);
			$table->text('desc')->nullable();
			$table->tinyInteger('included')->default(1);
			
			
			//Create the created_at column.
			$table->timestamp('created_at', $precision = 0);
			//Create active status
			$table->tinyInteger('active')->default(1);

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('adjustments');
    }
}
