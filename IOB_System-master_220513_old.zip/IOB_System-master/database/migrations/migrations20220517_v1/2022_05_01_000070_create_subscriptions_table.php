<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSubscriptionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('subscriptions', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('accId');
			$table->datetime('startDate');
			$table->datetime('endDate');
			
			
			//Create the created_at and updated_at columns.
			$table->timestamps($precision = 0);
			//Create the updatedBy columns.
			$table->unsignedBigInteger('updatedBy')->nullable();
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('updatedBy')->references('id')->on('accounts');
			$table->foreign('accId')->references('id')->on('accounts');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subscriptions');
    }
}
