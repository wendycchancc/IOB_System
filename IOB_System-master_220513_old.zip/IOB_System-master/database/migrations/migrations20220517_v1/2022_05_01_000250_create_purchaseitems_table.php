<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePurchaseitemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('purchaseitems', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('accId');
			$table->unsignedBigInteger('itemId');
			
			
			//Create the created_at column.
			$table->timestamp('created_at', $precision = 0);
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('accId')->references('id')->on('accounts');
			$table->foreign('itemId')->references('id')->on('itemsv1');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchaseitems');
    }
}
