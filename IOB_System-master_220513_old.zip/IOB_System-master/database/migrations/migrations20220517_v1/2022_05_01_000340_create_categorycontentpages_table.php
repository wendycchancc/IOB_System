<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCategorycontentpagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('categorycontentpages', function (Blueprint $table) {	
			$table->id();
			$table->unsignedBigInteger('contentpageId');
			$table->unsignedSmallInteger('categoryId');
			$table->unsignedSmallInteger('subcategoryId')->nullable();
			
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('contentpageId')->references('id')->on('contentpages');
			$table->foreign('categoryId')->references('id')->on('categories');
			$table->foreign('subcategoryId')->references('id')->on('subcategories');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('categorycontentpages');
    }
}
