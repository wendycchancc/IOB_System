<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFollowercontentpagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('followercontentpages', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('contentpageId');
			$table->unsignedBigInteger('accId');
			
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('contentpageId')->references('id')->on('contentpages');
			$table->foreign('accId')->references('id')->on('accounts');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('followercontentpages');
    }
}
