<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemdetailbooksTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('itemdetailbooks', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('itemId');
			$table->string('condition', 255);
			$table->text('title');
			$table->text('author')->nullable();
			$table->text('illustrator')->nullable();
			$table->string('edition', 255)->nullable();
			$table->string('format', 255)->nullable();
			$table->string('ISBN-10', 255)->nullable();
			$table->string('ISBN-13', 255)->nullable();
			$table->string('publisher', 255)->nullable();
			$table->datetime('publishDate')->nullable();
			$table->string('language', 255)->nullable();
			$table->integer('pages')->nullable();
			$table->mediumText('desc')->nullable();
			$table->unsignedBigInteger('coverPicId')->nullable();
			
			
			//Create the created_at and updated_at columns.
			$table->timestamps($precision = 0);
			//Create the createdBy and updatedBy columns.
			$table->unsignedBigInteger('createdBy');
			$table->unsignedBigInteger('updatedBy')->nullable();
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('createdBy')->references('id')->on('accounts');
			$table->foreign('updatedBy')->references('id')->on('accounts');
			$table->foreign('itemId')->references('id')->on('itemsv1');
			$table->foreign('coverPicId')->references('id')->on('pictures');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('itemdetailbooks');
    }
}
