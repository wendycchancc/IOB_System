<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEventparticipationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('eventparticipations', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('eventPostId');
			$table->unsignedBigInteger('accIdjoin');
			
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('eventPostId')->references('id')->on('eventposts');
			$table->foreign('accIdjoin')->references('id')->on('accounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('eventparticipations');
    }
}
