<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrderstatusesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('orderstatuses', function (Blueprint $table) {	
			
			$table->smallIncrements('id');
			$table->string('title', 255);
			
			
			//Create the created_at column.
			$table->timestamp('created_at', $precision = 0);
			//Create active status
			$table->tinyInteger('active')->default(1);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orderstatuses');
    }
}
