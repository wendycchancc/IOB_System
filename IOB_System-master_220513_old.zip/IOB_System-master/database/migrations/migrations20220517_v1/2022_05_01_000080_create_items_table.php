<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('itemsv1', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('accId');
			$table->string('inventoryStatus', 255);
			
			//Create the created_at and updated_at columns.
			$table->timestamps($precision = 0);
			//Create the createdBy and updatedBy columns.
			$table->unsignedBigInteger('createdBy');
			$table->unsignedBigInteger('updatedBy')->nullable();
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('createdBy')->references('id')->on('accounts');
			$table->foreign('updatedBy')->references('id')->on('accounts');
			$table->foreign('accId')->references('id')->on('accounts');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('itemsv1');
    }
}
