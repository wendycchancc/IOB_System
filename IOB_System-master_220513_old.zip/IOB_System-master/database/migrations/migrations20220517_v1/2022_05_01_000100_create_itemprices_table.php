<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItempricesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('itemprices', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('itemId');
			$table->decimal('price', 10, 2)->default(0);
			$table->char('currency', 4);
			$table->unsignedBigInteger('discountId')->nullable();
			$table->decimal('priceTotal', 10, 2)->nullable();
			
			
			//Create the created_at column.
			$table->timestamp('created_at', $precision = 0);
			//Create the createdBy columns.
			$table->unsignedBigInteger('createdBy');
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('createdBy')->references('id')->on('accounts');
			$table->foreign('itemId')->references('id')->on('itemsv1');
			$table->foreign('discountId')->references('id')->on('discounts');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('itemprices');
    }
}
