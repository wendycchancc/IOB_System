<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
	Schema::create('accounts', function (Blueprint $table) {			
				
				$table->id();
				$table->string('name', 255);
				$table->string('password', 255);
				$table->string('email', 255)->unique();
				$table->integer('phone');
				$table->string('address', 255)->nullable();
				$table->string('postcode', 255)->nullable();
				$table->string('country', 50)->nullable();
				$table->unsignedBigInteger('profilePicId');
				$table->unsignedSmallInteger('roleId');
				$table->tinyInteger('premiumStatus')->default(0);
				$table->timestamp('emailVerifiedAt', 1);
				
				
				//Create the created_at and updated_at columns.
				$table->timestamps($precision = 0);
				//Create the updatedBy columns.
				$table->unsignedBigInteger('updatedBy')->nullable();
				//Create active status
				$table->tinyInteger('active')->default(1);

			

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('accounts');
    }
}
