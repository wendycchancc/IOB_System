<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateItemcategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
		Schema::create('itemcategories', function (Blueprint $table) {	
			
			$table->id();
			$table->unsignedBigInteger('itemId');
			$table->unsignedSmallInteger('categoryId');
			$table->unsignedSmallInteger('subcategoryId')->nullable();
			
			//Create active status
			$table->tinyInteger('active')->default(1);
			
			// Create foreign key index
			$table->foreign('itemId')->references('id')->on('itemsv1');
			$table->foreign('categoryId')->references('id')->on('categories');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('itemcategories');
    }
}
