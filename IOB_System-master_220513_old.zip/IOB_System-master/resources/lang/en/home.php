<?php

return [
    'welcome' => 'Hello :)',
    'check' => 'Check the locale',
];
