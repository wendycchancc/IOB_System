<?php

return [
	'welcome' => 'こんにちは :)',
	'check' => 'ロケールを確認する',
];
