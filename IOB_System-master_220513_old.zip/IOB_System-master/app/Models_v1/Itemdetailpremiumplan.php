<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Itemdetailpremiumplan extends Model
{
protected $table = 'itemdetailpremiumplans'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'title', 'desc', 'duration', 'price', 'currency', 'startDate', 'endDate', 'created_at', 'updated_at', 'updatedBy', 'active'];

}
