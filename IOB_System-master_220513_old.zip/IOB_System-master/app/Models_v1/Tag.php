<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Tag extends Model
{
protected $table = 'tags'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = false; // Disable timestamps function
protected $fillable = ['id', 'tagTitle', 'created_at', 'createdBy', 'active'];

}
