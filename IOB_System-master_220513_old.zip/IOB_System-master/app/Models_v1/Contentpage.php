<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Contentpage extends Model
{
protected $table = 'contentpages'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'accId', 'status', 'title', 'desc', 'coverPicId', 'viewCount', 'created_at', 'updated_at', 'updatedBy', 'active'];

}
