<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Eventparticipation extends Model
{
protected $table = 'eventparticipations'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = false; // Disable timestamps function
protected $fillable = ['id', 'eventPostId', 'accId', 'active'];

}
