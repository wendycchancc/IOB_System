<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Discount extends Model
{
protected $table = 'discounts'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'title', 'desc', 'formula', 'startDate', 'endDate', 'created_at', 'createdBy', 'updated_at', 'updatedBy', 'active'];

}
