<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Eventpost extends Model
{
protected $table = 'eventposts'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'accId', 'title', 'desc', 'timeStart', 'timeEnd', 'status', 'coverPicId', 'created_at', 'updated_at', 'updatedBy', 'active'];

}
