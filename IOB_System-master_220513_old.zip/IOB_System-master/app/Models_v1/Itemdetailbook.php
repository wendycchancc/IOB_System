<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Itemdetailbook extends Model
{
protected $table = 'itemdetailbooks'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'itemId', 'condition', 'title', 'author', 'illustrator', 'edition', 'format', 'ISBN-10', 'ISBN-13', 'publisher', 'publishDate', 'language', 'pages', 'desc', 'coverPicId', 'created_at', 'createdBy', 'updated_at', 'updatedBy', 'active'];

}
