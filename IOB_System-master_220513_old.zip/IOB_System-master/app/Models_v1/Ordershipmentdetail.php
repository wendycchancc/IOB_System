<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Ordershipmentdetail extends Model
{
protected $table = 'ordershipmentdetails'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'orderId', 'name', 'email', 'phone', 'address', 'postcode', 'desc', 'created_at', 'createdBy', 'updated_at', 'updatedBy', 'active'];

}
