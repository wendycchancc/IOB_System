<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
protected $table = 'accounts'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'name', 'password', 'email', 'phone', 'address', 'postcode', 'country', 'profilePicId', 'roleId', 'premiumStatus', 'created_at', 'updated_at', 'updatedBy', 'emailVerifiedAt', 'active'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password'
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'emailVerifiedAt' => 'datetime'
    ];

}
