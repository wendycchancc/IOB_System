<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Itemv1 extends Model
{
protected $table = 'items'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'accId', 'inventoryStatus', 'created_at', 'createdBy', 'updated_at', 'updatedBy', 'active'];

}