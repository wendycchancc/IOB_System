<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Orderitemv1 extends Model
{
    //
}
