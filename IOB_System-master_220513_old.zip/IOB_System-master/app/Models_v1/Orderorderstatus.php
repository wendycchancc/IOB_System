<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Orderorderstatus extends Model
{
protected $table = 'orderorderstatuses'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = false; // Disable timestamps function
protected $fillable = ['id', 'orderId', 'orderStausId', 'desc', 'created_at', 'createdBy', 'active'];

}
