<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Orderstatus extends Model
{
protected $table = 'orderstatuses'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = false; // Disable timestamps function
protected $fillable = ['id', 'title', 'created_at', 'active'];

}
