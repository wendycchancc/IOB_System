<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Orderpaymentstatus extends Model
{
protected $table = 'orderpaymentstatuses'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = false; // Disable timestamps function
protected $fillable = ['id', 'orderId', 'paymentstatusId', 'desc', 'created_at', 'createdBy', 'active'];

}
