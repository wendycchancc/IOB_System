<?php

namespace App\Models_v1;

use Illuminate\Database\Eloquent\Model;

class Permission extends Model
{
protected $table = 'permissions'; // Define the table name
protected $primaryKey = 'id'; // Define the primary key column name
public $timestamps = true; // Eloquent timestamps function
protected $fillable = ['id', 'title', 'desc', 'created_at', 'updated_at', 'updatedBy', 'active'];

}
